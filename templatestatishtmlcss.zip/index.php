<html>
<head>
	<title>Badan Narkotika Nasional</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<script type="text/javascript" src="js/jquery-3.3.1.js"></script>
	<script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>

</head>

<body>

<nav id="navbar">
<img src="img/header.png">
<h1>BNN Indonesia</h1>
<p>Berantas Narkoba di Indonesia</p>

<ul class="btn-navbar">
        <li><a class="active2" href="index2.php">Beranda</a></li>
        <li><a href="#">Artikel</a></li>
        <li><a href="#">Volunteer</a></li>
		<li><a href="#">Kontak</a></li>
    </ul>
<form method="post" action="">
	<input type="image" class="btn btn-cari" src="img/search.png">
	<input type="text" class="form-search" placeholder="Cari disini">
</form>	
</nav>
<header id="header">
	
	<div id="slider">
		<div class="slide">
		<img src="img/header2.jpg" class="carousel">
		</div>
		
		<div class="slide">
		<img src="img/header1.jpg" class="carousel">
		
		</div>
	</div>
	
</header>
	
<aside id="sitebar">
<?php for($i=0;$i<2;$i++) { ?>
<div class="sitebar1">
<div id="sitebar2">
	<div class="header-menuarea">
		<img src="img/rss.jpg" class="icon-sitebar">
		<h3>Berita populer</h3>
	</div>
		<ul class="list-menuarea">
			<li><a href="#">Sosialisasi Narkotika di SMK Negeri 1 Lahat</a></li>
			<li><a href="#">Sosialisasi Narkotika di SMK Negeri 1 Lahat</a></li>
			<li><a href="#">Sosialisasi Narkotika di SMK Negeri 1 Lahat</a></li>
			<li><a href="#">Sosialisasi Narkotika di SMK Negeri 1 Lahat</a></li>
			<li><a href="#">Sosialisasi Narkotika di SMK Negeri 1 Lahat</a></li>
		</ul>
</div>
</div>
<?php } ?>	
</aside>

<?php for($i=0;$i<4;$i++) { ?>
<section id="content">
<div class="list-content">
<h3 class="label">sosialisasi | blog</h3>
	<video class="img-list-content" autoplay>
		<source src="img/portalcoding.mp4" type="video/mp4">  
	</video>
	<h2>Sosialisasi Narkotika di SMK Negeri 1 Lahat</h2>
	<p>Pada pembahasan kali ini kita akan membahas menganai cara membuat CRUD mengguna.....</p>
	
	<a href="artikel.php" class="btn-selengkapnya">Selengkapnya</a>
</div>
</section>
<?php } ?>	


<footer id="navfooter">
<div class="parallelogram">
</div>
</footer>

<footer id="footer">
<p class="copyright">Copyright &copy 2018. Allright Reserved</p>
<ul class="footer-icon">
	<li><a href="#"><img src="img/fb.png" class="fa-icon"></a></li>
	<li><a href="#"><img src="img/gp.png" class="fa-icon"></a></li>
	<li><a href="#"><img src="img/ig.png" class="fa-icon"></a></li>
	<li><a href="#"><img src="img/in.png" class="fa-icon"></a></li>
</ul>
</footer>

</body>
</html>
<script type="text/javascript">
 $(document).ready(function(){
	// Set Options
	var speed = 500;			// Fade speed
	var autoswitch = true;		// Auto slider options
	var autoswitch_speed = 4000	// Auto slider speed
	
	// Add initial active class
	$('.slide').first().addClass('active');
	
	// Hide all slides
	$('.slide').hide();
	
	// Show first slide
	$('.active').show();
	
	// Next Handler
	$('#next').on('click', nextSlide);
	
	// Prev Handler
	$('#prev').on('click', prevSlide);
	
	// Auto Slider Handler
	if(autoswitch == true){
		setInterval(nextSlide,autoswitch_speed);
	}
	
	// Switch to next slide
	function nextSlide(){
		$('.active').removeClass('active').addClass('oldActive');
		if($('.oldActive').is(':last-child')){
			$('.slide').first().addClass('active');
		} else {
			$('.oldActive').next().addClass('active');
		}
		$('.oldActive').removeClass('oldActive');
		$('.slide').fadeOut(speed);
		$('.active').fadeIn(speed);
	}
	
	// Switch to prev slide
	function prevSlide(){
		$('.active').removeClass('active').addClass('oldActive');
		if($('.oldActive').is(':first-child')){
			$('.slide').last().addClass('active');
		} else {
			$('.oldActive').prev().addClass('active');
		}
		$('.oldActive').removeClass('oldActive');
		$('.slide').fadeOut(speed);
		$('.active').fadeIn(speed);
	}
        });
	
	// Show first slide
	$('.active').show();
	
	// Next Handler
	$('#next').on('click', nextSlide);
	
	// Prev Handler
	$('#prev').on('click', prevSlide);
	
	// Auto Slider Handler
	if(autoswitch == true){
		setInterval(nextSlide,autoswitch_speed);
	}
	
	$(document).ready(function () {
    $("ul[efek] li").each(function (i) {
        $(this).attr("style", "animation-delay:" + i * 1000 + "ms");
        if (i == $("ul[efek] li").size() -1) {
            $("ul[efek]").addClass("play")
        }
    });
});

</script>